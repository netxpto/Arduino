#include "../include/transmission_control_20190410.h"

void TransmissionControl::initialize(void)
{
}

bool TransmissionControl::runBlock(void)
{
	return false;
}
